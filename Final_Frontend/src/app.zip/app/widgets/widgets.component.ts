import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { WidgetServicesService } from '../Services/widget-services.service';
import * as categories from '../categories.json';
import { MathcesCategoryPipe} from'../pipes/MathcesCategoryPipe';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SharedVarService } from '../Services/SharedVarService';
import { SubscriptionService } from '../Services/subscriptionService';
import { ToastrService } from 'ngx-toastr';
import { BASE_URL } from 'src/app/constants/constants';


@Component({
  selector: 'app-widgets',
  templateUrl: './widgets.component.html',
  styleUrls: ['./widgets.component.css']
})
export class WidgetsComponent implements OnInit {
  compCategories: any = (categories as any).default;
  srtName;
  srtPrice="free";
  sortType=false;
  currentUser
  widgetType;
  selectedCategory;
  selectedSubCategory;
  widgetList$ = new Observable<any>() ;
  baseUrl = BASE_URL;
  AllWidgets : any=[] ;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private sharVarService : SharedVarService,
    private widgetService : WidgetServicesService,
    private subscriptionService : SubscriptionService,
    private toastr : ToastrService
    ) {}

  ngOnInit(): void {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'))
    console.log(this.currentUser)
    this.widgetList$ = this.sharVarService.$widgetList.pipe(map(data => data));
    // this.widgetService.GetAllWidget().subscribe(data => {
    //   this.AllWidgets=data;
    //   console.log(this.AllWidgets);
    // });

    this.route.paramMap.subscribe(params => {
      this.selectedCategory = params.get("catType");
      this.selectedSubCategory = params.get("subCatType");
    })
  }

  openComponent(catValue){
    this.router.navigate(['/component/', catValue]);
  }

  openComponentWithSub(catValue,subCatValue){
    this.router.navigate(['/component/', catValue,subCatValue]);
  }

  downloadWidget(widget){
    this.widgetService.DownloadWidget(widget.file_path).subscribe((res: any) => {
      if(res.widget){
        let widgetObj=  widget;
        console.log(typeof widgetObj.downloaded);
        var downloadCount: number= +widgetObj.downloaded ;
        widgetObj.downloaded = downloadCount+1;
        this.widgetService.Update(widget.id,widgetObj).subscribe((updateRes: any) => {

        if(updateRes){
          window.location.href = this.baseUrl+"/downloadWidget/"+widget.file_path;
        }
        });
        // window.location.href = this.baseUrl+"/downloadWidget/"+widget.file_path;
      }else{
          this.toastr.error(res.message,'Failed');
      }
    });
  }

}
