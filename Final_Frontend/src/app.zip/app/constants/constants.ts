import { environment } from "src/environments/environment";
import * as Defaults from "../../assets/Defaults.json";


export const BASE_URL = environment.api_url;
// export const BASE_URL = "https://marketplace.aivhub
