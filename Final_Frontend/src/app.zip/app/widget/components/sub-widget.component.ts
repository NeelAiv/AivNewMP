import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-widget',
  templateUrl: './sub-widget.component.html',
  styleUrls: ['./sub-widget.component.css']
})
export class SubWidgetComponent implements OnInit {

  constructor(){}
  
  
  ngOnInit() {

  }

}
