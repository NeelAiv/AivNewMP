export class User {
    id: number;
    username: string;
    password: string;
    email: string;
    phone_number: number;
    role: string;
    created_date: Date;
    first_name: string;
    last_name: string;
    last_updated_date: Date
}