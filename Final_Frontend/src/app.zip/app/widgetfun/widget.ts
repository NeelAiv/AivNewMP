export class widget{
    
comment_id: number;
created_date: Date;
description: String;
details: String;
download_link: String;
downloaded: number;
features: String;
file_path: String;
id: number;
image: String;
last_update_date: Date;
no_of_comments: number;
price: number;
purchase_option: String;
rate: number;
refresh: number;
seller_name: String
size: number;
title: String;
type: String;
video_url: String;

}