import { widget } from './widget';

export const Widgets : widget [] =[];